const https = require("https");
const jwt = require('jsonwebtoken');

exports.handler = (event, context, callback) => {
    try {
        // Check authorization and parse JWT
        if (!event.headers.hasOwnProperty('Authorization')) throw new Error;
        let tokenElements = event.headers.Authorization.split(" ");
        if (tokenElements[0] != "Bearer") throw new Error;
        let decodedToken = jwt.verify(tokenElements[1], "MessageMedia");

        // Transform message format
        let input = JSON.parse(event.body);
        let message = {
            content : input.body,
            destination_number : input.recipient,
            source_number : input.sender
        };
    
        // Forward SMS using MessageMedia gateway
        let request = https.request({
            hostname : "api.messagemedia.com",
            path : "/v1/messages",
            auth : decodedToken.sub + ":" + decodedToken.aud,
            method : "POST",
            headers: { "Content-Type" : "application/json" }
        });
        request.write(JSON.stringify({
            messages : [ message ]
        }));            
        request.end();

        // No response required
        callback(null, {
            statusCode : 200,
            body : JSON.stringify({ status : 'sent' })
        });
    } catch (err) {
        // No response required
        callback(null, {
            statusCode : 401,
            body : JSON.stringify({ status : 'unauthorized' })
        });
    }
};